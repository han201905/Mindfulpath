
const path = require('path');

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const articlesRouter = require('./routes/articles');
const meditationsRouter = require('./routes/meditations');
const errorHandler = require('./middleware/errorHandler');

const app = express();

const MONGODB_URI = 'mongodb+srv://cloud:Password1438@cluster0.aybe0xt.mongodb.net/?retryWrites=true&w=majority';

const helmet = require('helmet');


require('dotenv').config();


// Connect to MongoDB
mongoose.connect(MONGODB_URI, { 
    useNewUrlParser: true, 
    useUnifiedTopology: true,
})
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Failed to connect to MongoDB:', err));


// Middleware
app.use(cors());
app.use(express.json());
app.use(helmet());


// Routes
app.use('/api/articles', articlesRouter);
app.use('/api/meditations', meditationsRouter);

// Error handler middleware
app.use(errorHandler);

const PORT = process.env.PORT || 8030;

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

//serve the static files from "build" folder in frontend
app.use(express.static(path.join(__dirname, '../../mindfulpath-frontend/build')));

app.get('*', (req, res) => {
  res.sendFile(path.resolve(__dirname, '../../mindfulpath-frontend/build', 'index.html'));
});

