const express = require('express');
const Meditation = require('../models/Meditation');

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const meditations = await Meditation.find();
    res.json(meditations);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.post('/', async (req, res) => {
  // Create a new meditation from request body data
  const meditation = new Meditation(req.body);

  try {
    const newMeditation = await meditation.save();
    res.status(201).json(newMeditation);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Add more routes as needed (PUT, DELETE, etc.)

module.exports = router;
