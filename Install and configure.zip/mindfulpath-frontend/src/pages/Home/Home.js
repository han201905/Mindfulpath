import React from 'react';

const Home = () => {
  return (
    <div>
      <h1>Welcome to MindfulPath!</h1>
      <p>Here's a brief introduction to our platform:</p>
      <ul>
        <li>We help you connect with experienced mindfulness teachers and guides.</li>
        <li>Our platform offers a range of courses, workshops, and retreats.</li>
        <li>You can explore different styles of mindfulness, such as mindfulness meditation, mindful movement, and mindful eating.</li>
        <li>We provide resources to help you develop and maintain a regular mindfulness practice.</li>
      </ul>
      <p>Ready to get started? Sign up or log in to your account to access our services.</p>
    </div>
  );
};

export default Home;
