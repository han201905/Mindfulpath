const mongoose = require('mongoose');

const MeditationSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },
  duration: {
    type: Number,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

const Meditation = mongoose.model('Meditation', MeditationSchema);

module.exports = Meditation;
