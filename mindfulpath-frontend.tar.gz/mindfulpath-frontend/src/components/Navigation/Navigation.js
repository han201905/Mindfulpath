import React from 'react';
import { Link } from 'react-router-dom';
import './Navigation.css'; // Import your CSS file if you have one.

const Navigation = () => {
    return (
      <header className="navigation">
        <h1>MindfulPath</h1>
        <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/techniques">Techniques</Link>
            </li>
            <li>
              <Link to="/meditations">Meditations</Link>
            </li>
            <li>
              <Link to="/articles">Articles</Link>
            </li>
            <li>
              <Link to="/about">About</Link>
            </li>
          </ul>
        </nav>
      </header>
    );
  };
  
  export default Navigation;
      