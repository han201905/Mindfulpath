import axios from 'axios';

const API_URL = 'https://mindfulpath.herokuapp.com';

export const fetchArticles = async () => {
  const response = await axios.get(`${API_URL}/api/articles`);
  return response.data;
};

export const createArticle = async (articleData) => {
  const response = await axios.post(`${API_URL}/api/articles`, articleData);
  return response.data;
};

export const updateArticle = async (id, articleData) => {
  const response = await axios.put(`${API_URL}/api/articles/${id}`, articleData);
  return response.data;
};

export const deleteArticle = async (id) => {
  const response = await axios.delete(`${API_URL}/api/articles/${id}`);
  return response.data;
};
